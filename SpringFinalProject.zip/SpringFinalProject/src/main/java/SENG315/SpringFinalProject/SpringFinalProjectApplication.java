package SENG315.SpringFinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFinalProjectApplication.class, args);
	}

}
