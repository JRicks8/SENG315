package SENG315.SpringFinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
